import pygame
import random
import threading
import sys

# constante
LUNGIME_ECRAN = 800
INALTIME_ECRAN = 600
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
DIMENSIUNE_MINIMA_BILA = 20
DIMENSIUNE_MAXIMA_BILA = 40
CULORI_BILE = [(255, 0, 0), (0, 255, 0), (0, 0, 255)]  # Roșu, Verde, Albastru
PUNCTE_PE_BILE = 10
PUNCTE_PENTRU_NIVEL_NOU = 100

class Bila:
    def __init__(self, x, y, dimensiune, culoare):
        self.x = x
        self.y = y
        self.dimensiune = dimensiune
        self.culoare = culoare

    def miscare(self):
        self.y += 5  

class BubbleBlastGame:
    def __init__(self):
        pygame.init()
        self.ecran = pygame.display.set_mode((LUNGIME_ECRAN, INALTIME_ECRAN))
        pygame.display.set_caption("Bubble Blast")
        self.ceas = pygame.time.Clock()
        self.bile = []
        self.punctaj = 0
        self.nivel = 1
        self.ruleaza = False

    def creare_bila(self):
        while self.ruleaza:
            dimensiune = random.randint(DIMENSIUNE_MINIMA_BILA, DIMENSIUNE_MAXIMA_BILA)
            culoare = random.choice(CULORI_BILE)
            x = random.randint(0, LUNGIME_ECRAN - dimensiune)
            bila = Bila(x, 0, dimensiune, culoare)
            self.bile.append(bila)
            pygame.time.wait(500)  

    def crestere_nivel(self):
        while self.ruleaza:
            if self.punctaj >= PUNCTE_PENTRU_NIVEL_NOU * self.nivel:
                self.nivel += 1
                print(f"Nivel Nou! Nivelul {self.nivel}")
            pygame.time.wait(1000)  

    def ruleaza_joc(self):
        self.ruleaza = True

        # thread pentru crearea bilelor
        thread_bila = threading.Thread(target=self.creare_bila)
        thread_bila.start()

        # thread pentru sistemul de creștere a nivelului
        thread_nivel = threading.Thread(target=self.crestere_nivel)
        thread_nivel.start()

        while self.ruleaza:
            for eveniment in pygame.event.get():
                if eveniment.type == pygame.QUIT:
                    self.ruleaza = False
                    pygame.quit()
                    sys.exit()

                if eveniment.type == pygame.MOUSEBUTTONDOWN:
                    for bila in self.bile:
                        if bila.x <= eveniment.pos[0] <= bila.x + bila.dimensiune and bila.y <= eveniment.pos[1] <= bila.y + bila.dimensiune:
                            self.bile.remove(bila)
                            self.punctaj += PUNCTE_PE_BILE

            self.ecran.fill(WHITE)

            for bila in self.bile:
                bila.miscare()
                pygame.draw.ellipse(self.ecran, bila.culoare, (bila.x, bila.y, bila.dimensiune, bila.dimensiune))

            # afișare punctaj și nivel
            font = pygame.font.SysFont(None, 30)
            text_punctaj = font.render(f"Punctaj: {self.punctaj}", True, BLACK)
            text_nivel = font.render(f"Nivel: {self.nivel}", True, BLACK)
            self.ecran.blit(text_punctaj, (10, 10))
            self.ecran.blit(text_nivel, (10, 40))

            pygame.display.flip()
            self.ceas.tick(60)

if __name__ == "__main__":
    joc = BubbleBlastGame()
    joc.ruleaza_joc()
